#!/bin/bash

###############
# setup-node.sh
#
# Long Le <lel@usi.ch>
# October 29h, 2019
#
# Purpose: install package dependencies for libramcast, set up system config
###############

# show the commands that are run for debugging in /root/setup/setup-node.log
set -x

USER_HOME=/users/lel

FLAG="/opt/.firstboot"
SETUPFLAG="/opt/.setup_in_process"
# FLAG will not exist on the *very* fist boot because
# it is created here!
if [ ! -f $FLAG ]; then
   sudo touch $FLAG
   sudo touch $SETUPFLAG
   REBOOT=yes
fi

# install packages
DEBIAN_FRONTEND=noninteractive sudo apt-get update
DEBIAN_FRONTEND=noninteractive sudo apt-get install -y zsh git vim htop cmake openjdk-8-jdk maven

# install oh-my-zsh
echo "n" | sh -c "$(curl -fsSL https://raw.githubusercontent.com/robbyrussell/oh-my-zsh/master/tools/install.sh)"
sudo sed -i 's/auth       required   pam_shells.so//g' /etc/pam.d/chsh
sudo groupadd chsh
sudo usermod -a -G chsh lel
sudo chsh -s $(which zsh)

DEBIAN_FRONTEND=noninteractive sudo apt-get install -y libtool autoconf automake build-essential libglib2.0-dev libmsgpack-dev
DEBIAN_FRONTEND=noninteractive sudo apt-get install -y ibverbs-utils rdmacm-utils infiniband-diags perftest libipathverbs1 libmlx4-1 libtool rdma-core librdmacm-dev libibverbs-dev numactl libnuma-dev libaio-dev libevent-dev

NOBODY_USR_GRP="nobody:nogroup"
sudo locale-gen en_US

for module in ib_umad ib_uverbs rdma_cm rdma_ucm ib_qib mlx4_core mlx4_en mlx4_ib; do
  echo $module | sudo tee -a /etc/modules
done

cat <<EOF | sudo tee $USER_HOME/.ssh/id_rsa
-----BEGIN OPENSSH PRIVATE KEY-----
b3BlbnNzaC1rZXktdjEAAAAABG5vbmUAAAAEbm9uZQAAAAAAAAABAAACFwAAAAdzc2gtcn
NhAAAAAwEAAQAAAgEAupQHwHozoVVAdj30JbR4jqfqIDgMsv1HXHxry5bl12fP0CCWhkC+
N7KuGKOykzGlC3obPCg9qYRzKmoz8XKgRy+VbuiDsrj+QOOOfWsBfQDqK0jMn4br23oyiq
6dAKslBW9RpCfiN0OInFCgwf+o1VbEfV5zPfVqDMLKttKXpfINLwbv7/X1zuFAw87Rrmn9
q96tm1fiaq8nDp9lUmrQTLVuiA9YEWPoEarLU/3bavqmRi9WEM6xxT/uCzy9SrtTLrhM2u
l0PyCwS564jevniEPbQ0mkZp210SVdFH05vYzCZcv/Q/JQPfnUE8RyXoc07OYmuJMM5v7H
RhIAv+AAmOYn0Fn3rO2/S97xrfWQrnBQSLj4JNKvbAxtMZ3CdFPQWJ8bmYdnxX1Zi1hdOz
L/yWuLL6CRbBhDYob4F0yLqzykNICQg12hvXmzzOM7KXmK3N+DDvA9jLGmobJG3ZealJAk
J9zMxKcZP/agqIzl+D8N2WupM/4E6icQGrZxMjUtLK3eootUBOTNwDAGTxE2vpduNDpSep
8o980DIsq8CaSbO2A9oWzo58gH+vyMapnssxaoibpCidwNPoNRtrNQEppAv/nzf5eVEymX
GGUuc8JNEZS2msk6EUe9itvbeY1++XZa6l18UmoSAW9smAE7eTsYGDEq5JX/MZ9zdKFlW+
UAAAdYRsEFfkbBBX4AAAAHc3NoLXJzYQAAAgEAupQHwHozoVVAdj30JbR4jqfqIDgMsv1H
XHxry5bl12fP0CCWhkC+N7KuGKOykzGlC3obPCg9qYRzKmoz8XKgRy+VbuiDsrj+QOOOfW
sBfQDqK0jMn4br23oyiq6dAKslBW9RpCfiN0OInFCgwf+o1VbEfV5zPfVqDMLKttKXpfIN
Lwbv7/X1zuFAw87Rrmn9q96tm1fiaq8nDp9lUmrQTLVuiA9YEWPoEarLU/3bavqmRi9WEM
6xxT/uCzy9SrtTLrhM2ul0PyCwS564jevniEPbQ0mkZp210SVdFH05vYzCZcv/Q/JQPfnU
E8RyXoc07OYmuJMM5v7HRhIAv+AAmOYn0Fn3rO2/S97xrfWQrnBQSLj4JNKvbAxtMZ3CdF
PQWJ8bmYdnxX1Zi1hdOzL/yWuLL6CRbBhDYob4F0yLqzykNICQg12hvXmzzOM7KXmK3N+D
DvA9jLGmobJG3ZealJAkJ9zMxKcZP/agqIzl+D8N2WupM/4E6icQGrZxMjUtLK3eootUBO
TNwDAGTxE2vpduNDpSep8o980DIsq8CaSbO2A9oWzo58gH+vyMapnssxaoibpCidwNPoNR
trNQEppAv/nzf5eVEymXGGUuc8JNEZS2msk6EUe9itvbeY1++XZa6l18UmoSAW9smAE7eT
sYGDEq5JX/MZ9zdKFlW+UAAAADAQABAAACAH+YirCcIcD8f2gduGEsyaGtvdSo4C5sPihG
wqVpneexDBKmpqpLjoqivKMHGDHHqrptmECMuJa8iNIB7WH65RepuAUwKBjKoL6ZoLGuw0
bMoFhXofCbIaNoLzZeceqqIFhWJ7wetnrayYs1LKtffwPfIeMm+6LsucjeUimzXZhUL6Xw
lZhCWgdQTq1aPFWOELhAQfPRp3sUK565bV5uw+Mh1ORhsfW6oFOsvP7ExhCkN6AZ8T7vS+
28abvvnviDoUB7M7wmGaSuY0Jj2ozcPuwWk9WxgCfZRSUx6zT+6sTxhWR+nSTHiw7HUrzu
BNUWnCBCyUpC7nju1jLaTv7pXx4Goz9Hp85fVVmecjlzlX2+rF4MfIQKZSEFjRxMs85Exm
hgjxdmMwVEFz2a1jQnsHqMVZF3PlobwzvDEGVS261nzG604t47jdT0KOCm95kLA9uD4Kn/
qHmtdHQcB2o4VFV8uf3SLpsJFARoqhd2Bf2s04QtaiGFrWTN0s/p1HvgR7QhW+c7MQczEI
k7YzeKnXCKFobEErIMBNDEwe6rT4+pnPEi42zzzZY4UhKyKHlHsCtJIjEf6fdAvijtqzxf
WEWJgipRu1ejUvVsmbZAtzZ1HKfolYxK8n5DldIOIhbp1Nchfo07btcNx27XxpmKfjc9ju
Stmfy8UOW1Mes1T0vlAAABAGBARqnpDsH5XhK+nyXRn0ezRuavOQ1XMm562BY+DK2XwQXP
JK9Mb77vCr5geL58WDNrhfM7XCca0AU3bAqI9Kb+pP0LUmw+e3gGzA7DpLRkmrxTkOQDPs
PJYVFGsLWCYza00R8OUI3b80BUrFw6PEDQPiAKiI01nhkbPMZ4Ur52j4FizTTI4IOKPX5h
/fK2I839d9GczTqChHcFp1R0vhb84uy4NT9g7Nke+xgXTqwvc0kEUJcD4i0Umib4zg/UXw
J5AUhiUk054vjkseqat/s6VtMAZn+Scxun+s4jt+WbEMRJYmHArojaV0MLRGy7rjGwN5IS
dg1jiT2yBhsTIAsAAAEBANr4rckjkzvDTJDzB5NwIXxLtrPt4masYglCE7S5lUwaWJx/BW
8tGnMo3bi6EIoNX8wp3je+1oZeP+07TTbfoHc7caTgcR9EcjfXyIrh29/hmi9AD9QFYZGQ
vuwyj5EPoK3Wm8nD8GHvktKEr5dpBYd3UE6DCv6AOQuLiJK4JmDMUsEpL7pbMcrU/eJ7JB
4rvPSXoszCUPRew/WUiIRNVWe1psZVsgNsm96OIGXk4dBBYdfv/aqDbuBbAK7UEdQnlYzM
d8z0v5gm2idLgeT73boP2Qq2y3Fj008MOMReI55Lf+RaGeWtc2Kwdn716AnE2+OMStrJlh
KW7bZtYSBusI8AAAEBANohC1j6OJ/LLaJ/NpAxk2aklBIybZBrFvlzqInM1vYu3i9K+S0D
In3KJuogerCBfNmLG21+9efREP6wIqmsEDwS+MgzimD6WxuUWe68LOhh9M8MMSCOxoi7Vp
FN7iunwjaaAMc1Alr0CI+tjM9TFPX3WJA8UpH1pZpBPyMEnDFNIyUIhLpom/hTG4i4v7RT
q/1I/qKocXYQfnDfHMunlTueniKgrj0G6uhwwq7ayMy49Rru7xrIA9Q2p+OOyPwInfFWH9
D6m1XRr09UlEbDHMMCviBydwGeFmkf3sCbCX+pRVbRlCr+mjtLGlzt67Nm9EcfrNhz2126
bLFCzWr7PksAAAAhbG9uZ2xlQExvbmdzLU1CUC5tb2JpbGUudXNpbHUubmV0AQI=
-----END OPENSSH PRIVATE KEY-----
EOF
sudo chmod 400 $USER_HOME/.ssh/id_rsa

# set the amount of locked memory. will require a reboot
sudo cat <<EOF  | sudo tee /etc/security/limits.d/90-rmda.conf
* soft memlock unlimited
* hard memlock unlimited
EOF

# setting up required library
sudo mkdir $USER_HOME/apps
sudo mkdir $USER_HOME/apps/libramcast

# set default java 8
sudo  update-java-alternatives --set /usr/lib/jvm/java-1.8.0-openjdk-amd64

cd $USER_HOME/apps/libramcast
sudo git clone https://github.com/zrlio/disni
cd disni
JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64 sudo mvn -DskipTests install
cd libdisni
sudo ./autoprepare.sh
sudo ./configure --with-jdk=/usr/lib/jvm/java-8-openjdk-amd64
sudo make
sudo make install

cd $USER_HOME/apps
sudo git clone https://bitbucket.org/sciascid/libpaxos.git
sudo mkdir libpaxos/build
cd libpaxos/build
sudo cmake ..
sudo make
sudo make install

cd $USER_HOME/apps
sudo git clone https://bitbucket.org/paulo_coelho/libmcast.git
sudo mkdir libmcast/build
cd libmcast/build
sudo cmake ..
sudo make
sudo make install

cd $USER_HOME/apps
sudo git clone https://github.com/imdea-software/atomic-multicast
cd atomic-multicast
# hack for the incompabability of white-box multicast with libmcast
sudo sed -i.bak 's/^typedef uint64_t m_uid_t;/\/\/ typedef uint64_t m_uid_t;/' /usr/local/include/mcast_types.h
sudo make

sudo sed -i.bak 's/^if(!good_dst && (g_dst_id == c->id)) {/if(!good_dst && (g_dst_id == c->id % c->groups_count)) {/g' /users/lel/apps/atomic-multicast/bench/node-bench.c

sudo chown -R lel:scalingsmr-PG0 $USER_HOME

if [[ "$REBOOT" == "yes" ]]; then
  # enact the change to the locked memory limits
  sudo reboot
fi
